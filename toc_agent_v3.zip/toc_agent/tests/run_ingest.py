import sys; sys.path.insert(0,'.'); sys.path.insert(0,'tests')
import pandas as pd
from gold import CASES
from toc_ingest import *
pd.set_option('display.width',220,'display.max_colwidth',70,'display.max_rows',300)
which = sys.argv[1:] or list(CASES)
for k in which:
    c=CASES[k]; name=c["file"]; data=open(name,"rb").read()
    grids=load_grids(name,data); st=Structure.from_dict(c["struct"]); g=grids[st.sheet]
    ex=extract_lines(g,st); an=analyze(ex,st)
    print("=====",k, "periods:",[p['label'] for p in ex.period_cols],"dropped:",[p['label'] for p in ex.dropped_cols])
    print(an.notes)
    print(pd.DataFrame(verification_report(g,st,an)).to_string(index=False))
    rec=reconcile(an,st); 
    if rec["table"] is not None: print(rec["table"].to_string(index=False))
    print("LEAVES",len(an.leaves))
    if "-v" in sys.argv or True:
        for lf in an.leaves: print(f"  {lf.id:6} m={lf.mult} {lf.path[:45]:45} | {lf.label[:50]:50} | {lf.vals[0]:>12,.2f}")
