"""Simulē to, ko Claude atgriež ar report_structure (zelta struktūras trim testa failiem)."""
UP = "/mnt/user-data/uploads/"
CASES = {
 "csv": dict(file=UP+"PZA_2026_2025_aktualizēti_dati_09_10_2026.csv", struct=dict(
    sheet="CSV",
    period_cols=[{"col":i,"label":f"{i:02d}.2026.","kind":"month"} for i in range(1,13)],
    first_row=3,last_row=65,result_row=14,sign_convention="mixed",totals_position="after",pl_layout="by_nature")),
 "tenachem": dict(file=UP+"Finansu_rezult_5_men__2024_copy.xlsx", struct=dict(
    sheet="PLn",
    period_cols=[{"col":3,"label":"05.2024.","kind":"month"},{"col":8,"label":"YTD","kind":"ytd"}],
    first_row=5,last_row=144,result_row=143,sign_convention="costs_negative",totals_position="after",pl_layout="by_nature")),
 "power": dict(file=UP+"Power_Solution_Bilance_pza_uz_31_12_2023_Operativie-2.xlsx", struct=dict(
    sheet="PZA",
    period_cols=[{"col":3,"label":"2023","kind":"year"}],
    first_row=2,last_row=76,result_row=76,sign_convention="costs_positive",totals_position="auto",pl_layout="by_nature")),
}
