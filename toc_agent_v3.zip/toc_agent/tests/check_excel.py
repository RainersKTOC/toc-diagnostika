import sys, subprocess, openpyxl, math
k=sys.argv[1]
subprocess.run(["python3","/mnt/skills/public/xlsx/scripts/recalc.py",f"/tmp/toc_{k}.xlsx","60"],capture_output=True)
a=openpyxl.load_workbook(f"/tmp/toc_{k}.xlsx",data_only=True).active
b=openpyxl.load_workbook(f"/tmp/toc_{k}_vals.xlsx",data_only=True).active
bad=0;n=0
for ra,rb in zip(a.iter_rows(),b.iter_rows()):
    for x,y in zip(ra,rb):
        if isinstance(x.value,(int,float)) or isinstance(y.value,(int,float)):
            n+=1
            xv=x.value if x.value not in ("",None) else None; yv=y.value
            if (xv is None)!=(yv is None) or (xv is not None and abs(xv-yv)>1e-6*max(1,abs(yv))):
                bad+=1; print("DIFF",x.coordinate,x.value,y.value)
print(k,"cells compared",n,"mismatches",bad)
