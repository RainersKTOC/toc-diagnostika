"""Pārbauda Claude izsaukumu plūsmu (retry/validācija) ar viltotu klientu — API atslēga nav vajadzīga."""
import sys; sys.path.insert(0,'.'); sys.path.insert(0,'tests')
from types import SimpleNamespace as NS
from gold import CASES
from toc_ingest import *
from toc_engine import *

class Fake:
    def __init__(self, outputs): self.outputs=list(outputs); self.calls=0; self.messages=self
    def create(self, **kw):
        self.calls+=1; out=self.outputs.pop(0)
        return NS(content=[NS(type="tool_use", name=kw["tool_choice"]["name"], input=out, id=f"t{self.calls}")])

c=CASES["tenachem"]; data=open(c["file"],"rb").read(); grids=load_grids(c["file"],data)
# 1) lapas izvēle
f=Fake([{"sheet":"PLn"}]); assert pick_sheet(f,"m",grids)=="PLn"
# 2) struktūra: 1. mēģinājums ar kolonnu ārpus lapas -> kļūda -> 2. mēģinājums pareizs
bad=dict(c["struct"]); bad["period_cols"]=[{"col":99,"label":"x","kind":"month"}]
f=Fake([bad, c["struct"]]); st=request_structure(f,"m","PLn",grids["PLn"])
assert f.calls==2 and st.first_row==5; print("structure retry OK")
# 3) klasifikācija: 1. atbilde nepilna -> retry
an=analyze(extract_lines(grids["PLn"],st),st); L=an.leaves
partial={"items":[{"id":L[0].id,"group":"S","is_income":True,"confidence":"high"}]}
full={"items":[{"id":l.id,"group":"OE_OTHER","is_income":False,"confidence":"high"} for l in L]}
f=Fake([partial,full]); items=classify_with_claude(f,"m",L); assert f.calls==2 and len(items)==len(L); print("classify retry OK")
# 4) nederīga grupa
badg={"items":[{"id":l.id,"group":"XYZ","is_income":False,"confidence":"high"} for l in L]}
f=Fake([badg,badg,badg])
try: classify_with_claude(f,"m",L); print("NO ERROR?!")
except ValueError as e: print("invalid group rejected OK")
