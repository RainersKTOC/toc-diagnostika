import sys; sys.path.insert(0,'.'); sys.path.insert(0,'tests')
import numpy as np, pandas as pd
from gold import CASES
from toc_ingest import *
from toc_engine import *
pd.set_option('display.width',250,'display.max_columns',40,'display.float_format',lambda x:f"{x:,.2f}")

def mock_claude(leaves):
    """Vienkāršs atslēgvārdu klasifikators — aizstāj Claude testā (tikai lai pārbaudītu Python daļu)."""
    out={}
    for l in leaves:
        t=(l.path+" "+l.label).lower(); lab=l.label.lower(); g="OE_OTHER"; inc=False
        if "neto apgrozījums" in lab or "sales" in lab and "interco" in lab or "third party sales" in lab or "discounts customers" in lab or "ieņēmumi no pamatdarb" in lab or "ar īpašiem nod" in lab or "citu periodu ieņ" in lab: g,inc="S",True
        elif "izejvielu" in lab or "purchased goods" in lab or "stock movements" in lab: g="TVC_MATERIALS"
        elif "preču piegādes" in lab or "outbound" in lab or "inbound" in lab: g="TVC_DELIVERY"
        elif ("personāla izmaksas" in lab or "sociālās" in lab) : g="OE_ADMIN_WAGES" if "administr" in t else "OE_WORKER_WAGES"
        elif "payroll charges" in lab and "blue" in t: g="OE_WORKER_WAGES"
        elif "payroll charges" in lab and "white" in t: g="OE_ADMIN_WAGES"
        elif "reklām" in lab or "mārketing" in lab: g="OE_MARKETING"
        elif any(k in lab for k in ("platformu","pārējās pārdošanas","mājas lapas","us tax")): g="OE_PLATFORMS"
        elif "ražošanas telpu" in lab or "pārējās ražošanas" in lab: g="OE_PREMISES"
        elif any(k in lab for k in ("biroja","telpu noma","sakaru","it infr")): g="OE_OFFICE_IT"
        elif any(k in lab for k in ("procentu","ienākuma nodoklis","nolietojums","depreciation","interest","taxes","nodoklis no peļņas","norakstīšana","tax on")) : g="EXCLUDED"
        elif any(k in lab for k in ("granta","pārējie ieņēmumi","citi ieņēmumi")) or "operating income" in t: g,inc="OE_OTHER",True
        elif l.code in ("7210","7310","7330","7340","7250","7240"): g="OE_WORKER_WAGES"
        elif l.code in ("7220","7320","7350","7260"): g="OE_ADMIN_WAGES"
        out[l.id]={"group":g,"is_income":inc}
    return out

k=sys.argv[1]; c=CASES[k]; data=open(c["file"],"rb").read()
st=Structure.from_dict(c["struct"]); g=load_grids(c["file"],data)[st.sheet]
ex=extract_lines(g,st); an=analyze(ex,st)
mp=mock_claude(an.leaves)
income={i for i,m in mp.items() if m["is_income"]}
rec=reconcile(an,st,income); print("reconcile:",rec["status"],rec["message"])
pos=next(l.pos for l in ex.lines if l.row==st.result_row)
res=compute_toc(an.leaves,mp,ex.period_cols,ex.lines[pos].vals)
print(res.main.loc[:, [c for c in res.main.columns if not c.startswith('%|')]].round(0).to_string())
print(res.kpi.to_string())
print(pd.DataFrame(res.checks).to_string(index=False))
build_excel(res,f"/tmp/toc_{k}.xlsx"); print("excel ok")
build_excel(res,f"/tmp/toc_{k}_vals.xlsx",formulas=False)
